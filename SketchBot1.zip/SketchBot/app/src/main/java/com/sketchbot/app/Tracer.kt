package com.sketchbot.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PointF
import android.net.Uri

object Tracer {

    class Result(val strokes: List<List<PointF>>, val w: Int, val h: Int, val preview: Bitmap)

    fun load(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (Math.max(o.outWidth, o.outHeight) / s > maxSide * 2) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, o2)
        } ?: return null
        val k = maxSide.toFloat() / Math.max(bmp.width, bmp.height)
        return if (k < 1f) Bitmap.createScaledBitmap(
            bmp,
            Math.max(1, (bmp.width * k).toInt()),
            Math.max(1, (bmp.height * k).toInt()),
            true
        ) else bmp
    }

    fun process(src: Bitmap, threshold: Int): Result {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val mask = BooleanArray(w * h)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val c = px[y * w + x]
                val a = Color.alpha(c)
                val g = if (a < 128) 255.0 else
                    0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)
                mask[y * w + x] = g < threshold
            }
        }

        thin(mask, w, h)
        val strokes = trace(mask, w, h)

        val out = IntArray(w * h) { if (mask[it]) Color.BLACK else Color.WHITE }
        val prev = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        prev.setPixels(out, 0, w, 0, 0, w, h)
        return Result(strokes, w, h, prev)
    }

    // Zhang-Suen thinning
    private fun thin(img: BooleanArray, w: Int, h: Int) {
        var changed = true
        val del = ArrayList<Int>()
        while (changed) {
            changed = false
            for (step in 0..1) {
                del.clear()
                for (y in 1 until h - 1) {
                    for (x in 1 until w - 1) {
                        val i = y * w + x
                        if (!img[i]) continue
                        val p2 = img[i - w]
                        val p3 = img[i - w + 1]
                        val p4 = img[i + 1]
                        val p5 = img[i + w + 1]
                        val p6 = img[i + w]
                        val p7 = img[i + w - 1]
                        val p8 = img[i - 1]
                        val p9 = img[i - w - 1]
                        val seq = booleanArrayOf(p2, p3, p4, p5, p6, p7, p8, p9, p2)
                        var n = 0
                        for (k in 0 until 8) if (seq[k]) n++
                        if (n < 2 || n > 6) continue
                        var a = 0
                        for (k in 0 until 8) if (!seq[k] && seq[k + 1]) a++
                        if (a != 1) continue
                        if (step == 0) {
                            if (p2 && p4 && p6) continue
                            if (p4 && p6 && p8) continue
                        } else {
                            if (p2 && p4 && p8) continue
                            if (p2 && p6 && p8) continue
                        }
                        del.add(i)
                    }
                }
                if (del.isNotEmpty()) {
                    changed = true
                    for (i in del) img[i] = false
                }
            }
        }
    }

    private val dxs = intArrayOf(1, -1, 0, 0, 1, 1, -1, -1)
    private val dys = intArrayOf(0, 0, 1, -1, 1, -1, 1, -1)

    private fun trace(sk: BooleanArray, w: Int, h: Int): List<List<PointF>> {
        val visited = BooleanArray(w * h)
        val out = ArrayList<List<PointF>>()
        val step = 3

        fun neighborCount(i: Int): Int {
            val x = i % w
            val y = i / w
            var n = 0
            for (k in 0 until 8) {
                val nx = x + dxs[k]
                val ny = y + dys[k]
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                if (sk[ny * w + nx]) n++
            }
            return n
        }

        fun walk(start: Int) {
            val pts = ArrayList<Int>()
            var cur = start
            while (true) {
                visited[cur] = true
                pts.add(cur)
                val cx = cur % w
                val cy = cur / w
                var next = -1
                for (k in 0 until 8) {
                    val nx = cx + dxs[k]
                    val ny = cy + dys[k]
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val ni = ny * w + nx
                    if (sk[ni] && !visited[ni]) { next = ni; break }
                }
                if (next < 0) break
                cur = next
            }
            if (pts.size < 4) return
            val res = ArrayList<PointF>()
            var k = 0
            while (k < pts.size) {
                res.add(PointF(pts[k] % w + 0.5f, pts[k] / w + 0.5f))
                k += step
            }
            if ((pts.size - 1) % step != 0) {
                val l = pts[pts.size - 1]
                res.add(PointF(l % w + 0.5f, l / w + 0.5f))
            }
            if (res.size >= 2) out.add(res)
        }

        for (i in sk.indices) if (sk[i] && !visited[i] && neighborCount(i) <= 1) walk(i)
        for (i in sk.indices) if (sk[i] && !visited[i]) walk(i)
        return out
    }
}
